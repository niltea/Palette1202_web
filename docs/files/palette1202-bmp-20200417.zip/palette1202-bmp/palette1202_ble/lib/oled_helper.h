#ifdef OLED_DRIVER_ENABLE
#ifndef OLED_HELPER_H
#define OLED_HELPER_H

void render_row(int row, const char* status);

#endif /* #ifndef OLED_HELPER_H */
#endif /* #ifdef OLED_DRIVER_ENABLE */
  