# firmware for Palette1202 BLE

BLE Micro Pro（以下BMP）用のPalette1202ファームウェアです。

## 内容物

### US / JIS フォルダ以下

Windows環境ではJIS/USキーボードが混在不可のため、
Windows環境で使用される場合はJISフォルダを使用してください。
iOS / Mac環境のみで使用される場合はUSフォルダで問題ありません。

- palette1202_ble_default.uf2

BMP用のファームウェアです。
Bootloader 5.0.x を書き込んだBMPに転送してください。
※configファイルだけを書き込んだ場合、OLEDディスプレイとエンコーダーが動作しません。
ファームウェアの書き込みをおねがいします。

- config/ フォルダ以下

config / keymapファイルです。
ファームウェア書き込み後、BMPをマスストレージデバイスとして接続し、転送してください。

### palette1202_ble/

QMK Firmware(BLE)用のソース一式です。
keyboards以下にコピーし、適宜編集・コンパイルを行ってください。
