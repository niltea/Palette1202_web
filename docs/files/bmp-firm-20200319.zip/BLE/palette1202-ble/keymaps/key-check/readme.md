# The test-purpose keymap for niltea
組み立て後のテスト用keymapです。